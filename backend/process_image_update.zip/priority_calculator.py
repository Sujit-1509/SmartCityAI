"""
priority_calculator.py — Smart Priority Scoring Engine for CivicAI.

Calculates a priority score (0–100) for each complaint based on:
    1. Severity Level     — Higher severity = higher score
    2. Category Danger    — Safety-critical categories score higher
    3. Model Confidence   — Higher confidence = more reliable = higher score
    4. Duplicate Boost    — Same category from nearby location = boosted priority

The priority score is stored in DynamoDB and used by the admin dashboard
to sort and triage complaints efficiently.
"""

import logging
import boto3
from decimal import Decimal
from boto3.dynamodb.conditions import Attr

logger = logging.getLogger(__name__)

# ── Scoring Weights ──────────────────────────────────────────────────────────
SEVERITY_SCORES = {
    "high":           40,
    "medium":         25,
    "low":            10,
    "pending review":  5,
}

CATEGORY_SCORES = {
    "pothole":     20,   # Vehicles can be damaged, safety hazard
    "water":       25,   # Waterlogging/flooding, public health risk
    "garbage":     15,   # Sanitation, but lower immediate danger
    "streetlight": 18,   # Safety at night, crime risk
}

DEFAULT_CATEGORY_SCORE = 10

# Nearby duplicates within this radius (in degrees, ~1km ≈ 0.009)
NEARBY_THRESHOLD_DEG = 0.01
DUPLICATE_BOOST_PER_MATCH = 5  # +5 per nearby same-category complaint
MAX_DUPLICATE_BOOST = 20       # Cap at +20


def calculate_priority(
    category: str,
    severity: str,
    confidence: float,
    latitude: float = None,
    longitude: float = None,
    table_name: str = None,
) -> int:
    """
    Calculate a smart priority score (0–100) for a complaint.

    Scoring breakdown:
        • Severity   (0–40): Based on severity level
        • Category   (0–25): Based on category danger level
        • Confidence (0–15): Scaled from model confidence (0.0–1.0)
        • Duplicates (0–20): Bonus for existing complaints nearby with same category

    Args:
        category:   Detected issue type (e.g., "pothole", "garbage").
        severity:   Severity level (e.g., "High", "Medium", "Low").
        confidence: YOLO model confidence (0.0 to 1.0).
        latitude:   GPS latitude of the complaint location.
        longitude:  GPS longitude of the complaint location.
        table_name: DynamoDB table name (for duplicate lookups).

    Returns:
        Integer priority score between 0 and 100.
    """
    score = 0
    cat = category.lower().strip()
    sev = severity.lower().strip()

    # ── 1. Severity Score (max 40) ───────────────────────────────────────────
    score += SEVERITY_SCORES.get(sev, 5)

    # ── 2. Category Danger Score (max 25) ────────────────────────────────────
    score += CATEGORY_SCORES.get(cat, DEFAULT_CATEGORY_SCORE)

    # ── 3. Confidence Score (max 15) ─────────────────────────────────────────
    conf_score = int(min(confidence, 1.0) * 15)
    score += conf_score

    # ── 4. Duplicate/Cluster Boost (max 20) ──────────────────────────────────
    duplicate_boost = 0
    if latitude and longitude and table_name:
        try:
            duplicate_boost = _count_nearby_duplicates(
                cat, latitude, longitude, table_name
            )
        except Exception as exc:
            logger.warning("Duplicate lookup failed: %s", str(exc))

    score += min(duplicate_boost * DUPLICATE_BOOST_PER_MATCH, MAX_DUPLICATE_BOOST)

    # Clamp to 0–100
    final_score = max(0, min(100, score))

    logger.info(
        "Priority calculated: severity=%d, category=%d, confidence=%d, "
        "duplicates=%d (boost=%d) → total=%d",
        SEVERITY_SCORES.get(sev, 5),
        CATEGORY_SCORES.get(cat, DEFAULT_CATEGORY_SCORE),
        conf_score,
        duplicate_boost,
        min(duplicate_boost * DUPLICATE_BOOST_PER_MATCH, MAX_DUPLICATE_BOOST),
        final_score,
    )

    return final_score


def _count_nearby_duplicates(
    category: str,
    latitude: float,
    longitude: float,
    table_name: str,
) -> int:
    """
    Query DynamoDB for complaints of the same category near the given location.

    Uses a full table scan with filters (acceptable for MVP scale).
    For production, consider a GSI on category + geohash.

    Returns:
        Number of matching nearby complaints.
    """
    dynamodb = boto3.resource("dynamodb", region_name="ap-south-1")
    table = dynamodb.Table(table_name)

    lat_min = Decimal(str(latitude - NEARBY_THRESHOLD_DEG))
    lat_max = Decimal(str(latitude + NEARBY_THRESHOLD_DEG))
    lng_min = Decimal(str(longitude - NEARBY_THRESHOLD_DEG))
    lng_max = Decimal(str(longitude + NEARBY_THRESHOLD_DEG))

    try:
        response = table.scan(
            FilterExpression=(
                Attr("category").eq(category)
                & Attr("latitude").between(lat_min, lat_max)
                & Attr("longitude").between(lng_min, lng_max)
            ),
            ProjectionExpression="incident_id",
            Limit=50,
        )
        count = response.get("Count", 0)
        logger.info(
            "Found %d nearby '%s' complaints within %.4f° radius",
            count, category, NEARBY_THRESHOLD_DEG,
        )
        return count
    except Exception as exc:
        logger.warning("DynamoDB scan for duplicates failed: %s", str(exc))
        return 0
